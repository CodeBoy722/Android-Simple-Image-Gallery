package com.androidcodeman.simpleimagegallery.utils;

public interface imageIndicatorListerner {

    public void onImageIndicatorClicked(int ImagePosition);
}
